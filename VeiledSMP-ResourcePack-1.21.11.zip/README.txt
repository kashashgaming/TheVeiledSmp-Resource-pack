THE VEILED SMP RESOURCE PACK
Minecraft Java Edition 1.21.11
Resource Pack Format: 75.0

Custom item models:
- veiledsmp:veil_fragment
- veiledsmp:life_crystal
- veiledsmp:shadow_crystal
- veiledsmp:storm_crystal
- veiledsmp:time_crystal
- veiledsmp:void_crystal

This pack is designed to be used with the matching VeiledSMP plugin build,
which assigns these item_model components to the protected Veil/Crystal items.
